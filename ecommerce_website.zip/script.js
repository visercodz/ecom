
let cart = [];

function addToCart(name, price) {
    let item = cart.find(product => product.name === name);
    if (item) {
        item.quantity += 1;
    } else {
        cart.push({ name: name, price: price, quantity: 1 });
    }
    displayCart();
}

function removeFromCart(index) {
    cart.splice(index, 1);
    displayCart();
}

function displayCart() {
    const cartContents = document.getElementById('cart-contents');
    const cartTotal = document.getElementById('cart-total');
    cartContents.innerHTML = '';
    cart.forEach((product, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${product.name}</td>
            <td>$${product.price}</td>
            <td>${product.quantity}</td>
            <td>$${(product.price * product.quantity).toFixed(2)}</td>
            <td><button class="remove-item" data-index="${index}">Remove</button></td>
        `;
        cartContents.appendChild(row);
    });
    let total = cart.reduce((sum, product) => sum + (product.price * product.quantity), 0);
    cartTotal.textContent = total.toFixed(2);
}

document.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-to-cart')) {
        const name = e.target.dataset.name;
        const price = parseFloat(e.target.dataset.price);
        addToCart(name, price);
    }
    if (e.target.classList.contains('remove-item')) {
        const index = parseInt(e.target.dataset.index);
        removeFromCart(index);
    }
});
